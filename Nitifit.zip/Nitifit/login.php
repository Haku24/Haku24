<?php
include_once 'config.php';

// Check if form is submitted
if (isset($_POST['fullname'])) {
    $fullname = $_POST['fullname'];
    $password = $_POST['password'];

    // Prepare a SELECT statement
    $sql = "SELECT id FROM login WHERE fullname = '$fullname' AND password = '$password'";

    // Execute the statement
    $result = $conn->query($sql);

    // Check if a row was returned
    if ($result->num_rows > 0) {
        // Fetch the first row (there should only be one)
        $row = $result->fetch_assoc();
        echo "<script>alert('Login Successfuly!'); location.href = 'nitifit.php';</script>" ;
    } else {
        echo "<script>alert('Invalid username or password!');</script>";
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NitiFit Log In</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #FFFCF4;
        }
        .signup-container {
            background-color: #b0a47d;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3); 
            width: 300px;
        }
        .signup-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .signup-container input[type="text"],
        .signup-container input[type="password"],
        .signup-container input[type="submit"] {
            width: calc(100% - 45px); /* Adjusted width */
            padding: 10px;
            border: 1px solid black;
            border-radius: 5px;
            box-sizing: border-box;
            display: block;
            margin: 0 auto 15px;
            padding-left: 35px; /* Adjusted padding to make space for the icon */
            position: relative; /* Added */
        }
        .signup-container .icon {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            left: 10px;
            color: #ccc;
        }
        .signup-btn {
            background-color: #635a3d; /* Green color */
            color: white;
            cursor: pointer;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            margin-top: 10px;
        }
        .signup-container .signup-btn:hover {
            background-color: beige;
            color: black;
        }
        .signup-container .login-link {
            text-align: center;
            margin-top: 15px;
        }
        .signup-container .login-link a {
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h2>Log In <i class="fas fa-user"></i></h2>
        <form action="" method="post">
            <div style="position:relative;">
                <input type="text" name="fullname" placeholder="Username" style="font-family:Arial" required>
                <i class="fas fa-user icon" style="left: 35px;"></i>
            </div>
            <div style="position:relative;">
                <input type="password" name="password" placeholder="Password" style="font-family:Arial" required>
                <i class="fas fa-lock icon" style="left: 35px;"></i>
            </div>
            <input type="submit" name="submit" value="Log In" class="signup-btn">
        </form>
        <div class="login-link">
            <span>Don't have an account?</span>
            <span>|</span>
            <a href="sign.php">Sign Up</a>
        </div>
    </div>
</body>
</html>