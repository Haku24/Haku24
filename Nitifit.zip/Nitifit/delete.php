<?php
    include_once 'config.php';

    $id = $_GET['id'];

    $sql = "DELETE FROM shop WHERE id = '$id'";

    if (mysqli_query($conn, $sql)) {
    
        echo "<script>
                alert('Item removed from cart!');
                location.href = 'cart.php';
              </script>";
    }
    mysqli_close($conn);
?>