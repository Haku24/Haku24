<?php 

echo "<script>alert('Order Pending. Please wait for your order to be verified!'); location.href='cart.php';</script>"

?>