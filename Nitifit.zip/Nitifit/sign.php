<?php 

include_once 'config.php';

if(isset($_POST['submit'])){

    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "INSERT INTO `login` (`fullname`,`email`,`password`) VALUES ('$fullname','$email','$password')";

    if(mysqli_query($conn, $query)){
        echo "<script>
                alert('Sign up Successfully!'); location.href = 'login.php';
            </script>";

    mysqli_close($conn);
}
}   
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NitiFit Sign Up</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #FFFCF4;
        }
        .signup-container {
            background-color: #b0a47d;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.3); 
            width: 300px;
        }
        .signup-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .signup-container input[type="text"],
        .signup-container input[type="email"],
        .signup-container input[type="password"],
        .signup-container input[type="submit"] {
            width: calc(100% - 45px); /* Adjusted width */
            padding: 10px;
            border: 1px solid black;
            border-radius: 5px;
            box-sizing: border-box;
            display: block;
            margin: 0 auto 15px;
            padding-left: 35px; /* Adjusted padding to make space for the icon */
            position: relative; /* Added */
        }
        .signup-container .icon {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            left: 10px;
            color: #ccc;
        }
        .signup-btn {
            background-color: #635a3d;
            color: white;
            cursor: pointer;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            margin-top: 10px;
        }
        .signup-container .signup-btn:hover {
            background-color: beige;
            color: black;
        }
        .signup-container .login-link {
            text-align: center;
            margin-top: 15px;
        }
        .signup-container .login-link a {
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h2>Sign Up <i class="fas fa-user-plus"></i></h2>
        <form action="sign.php" method="post">
            <div style="position:relative;">
                <input type="text" name="fullname" placeholder="Full Name" style="font-family:Arial" required>
                <i class="fas fa-user icon" style="left: 35px;"></i>
            </div>
            <div style="position:relative;">
                <input type="email" name="email" placeholder="Email" style="font-family:Arial" required>
                <i class="fas fa-envelope icon" style="left: 35px;"></i>
            </div>
            <div style="position:relative;">
                <input type="password" name="password" placeholder="Password" style="font-family:Arial" required>
                <i class="fas fa-lock icon" style="left: 35px;"></i>
            </div>
            <input type="submit" name="submit" value="Sign Up" class="signup-btn">
        </form>
        <div class="login-link">
            <span>Already have an account?</span>
            <span>|</span>
            <a href="login.php">Log In</a>
        </div>
    </div>
</body>
</html>