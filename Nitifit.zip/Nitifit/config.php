<?php

$host = "localhost";
$username = "root";
$password = "";
$databasename = "nitifitdb";

$conn = mysqli_connect($host,$username,$password,$databasename);

if(!$conn){
    die("Connection Failed: " . mysqli_connect_error());
}