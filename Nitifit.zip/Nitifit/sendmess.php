<?php 

echo "<script>alert('Message sent to admin.'); location.href= 'message.php';</script>";

?>