<?php
include_once 'config.php';

if(isset($_POST['send'])){

    $userid = $_POST['userid'];
    $reply = $_POST['reply'];

    $sql = "UPDATE faq SET reply = '$reply'";

    if(mysqli_query($conn, $sql)){

        echo "<script>
            alert('Reply sent successfully!');
            location.href = 'replies.php';
            </script>";
        } else {
        echo "<script>
            alert('Unable to send reply. Please try again later!');
            </script>";
        }
        mysqli_close($conn);
    }
?>
