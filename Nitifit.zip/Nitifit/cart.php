<?php

include_once 'config.php'; 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="my_jquery_functions.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <title>Home</title>
    <style>
        body {
            padding: 0;
            margin: 0;
            background: #FFFCF4;
        }
/*Navbar*/
.navbar{
            border: 1px solid beige;
            padding-right: 4%;
            padding-left: 4%;
            padding-top: 2%;
            background: beige;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 4;
        }

        .home {
            text-decoration: none;
        }

        .navlist ul {
            display: flex;
            list-style-type: none;
            margin-top: 10px;
            padding: 0;
            margin-right: 335px;
        }
        .navlist li {
            margin-right: 20px;
            margin-left: 20px;
        }

        .list {
            text-decoration: none;
            color: black; /* Original color */
            font-size: 20px;
        }

        .list:hover {
            text-decoration: none;
            background-color: #96875A;
            border-radius: 30px;
            color: white;
        }

        .shop {
            text-decoration: none;
            border: 2px solid #3A3A3A;
            border-radius: 30px;
            color: #96875A;
            font-size: 20px;
            background-color: beige;
        }

        .shop:hover {
            text-decoration: none;
            border-radius: 30px;
            color: white;
            font-size: 20px;
            background-color: #96875A;
        }

        .searchBar {
            display: flex;
            align-items: center;
        }

        .searchBar input[type="text"] {
            border-radius: 20px;
            padding: 5px 10px;
            border: 1px solid #ccc;
        }

        .search{
            background: white;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .search:hover {
            background: #765700;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .menu {
            width: 30px;
            height: 4px;
            background-color: #3A3A3A;
            margin: 5.5px;
            border-radius: 15%;
        }
        .menuBar {
            border: 1px solid beige;
            background-color: beige;
            padding-bottom: 7px;
            width: 100%;
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            position: absolute;
            z-index: 3;
        }
        .pointer {
            cursor: pointer;
            width: 30px;
            margin-left: 59px;
        }
        /*Menu Bar*/
        .menuItems{
            background-color: rgba(245, 245, 220, 0.75);
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            width: 15%;
            padding-top: 60px;
            z-index: 2;
            position: absolute;
            display: none;
        }

        .menuList{
            text-decoration: none;
        }
        
        .menubg {
            list-style-type: none;
            width: 80%;
            padding: 5%;
            margin-top: 10px;
            border-radius: 50px;
            text-decoration: none;
            color: black; /* Original color */
        }
        .menubg:hover {
            text-decoration: none;
            list-style-type: none;
            background-color: #96875A;
            color: white;
        }
        

/* Footer */
.footer {
            margin-top: 30px;
            background-color: #956c00;
            display: flex;
            text-align: center;
            color: white;
            width: 100%;
            padding-top: 10px;
            bottom: 0;
            left: 0;
         }

        .icons {
            margin-top: 40px;
        }

        .socmed {
            display: inline-block;
            margin-right: 10px; /* Adjust margin as needed */
        }

        .foot1 {
            margin-left: 7%;
        }

        .foot2 {
            margin-left: 20%;
            margin-top: 20px;
        }

        .foot3 {
            margin-left: 25%;
        }
/* Content */
.container {
        background: beige;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        padding: 20px;
        margin-top: 75px;
        width: 75%;
        text-align: center;
        margin-bottom: 100px;
    }
    .flex {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        justify-content: center;
        justify-content: space-between;
    }
    .card {
        padding: 10px;
        width: 30%;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        height: 350px;
        margin-top: 50px;
        margin-bottom: 50px;
    }
    .id {
        font-size: 14px;
    }
    #hr {
        margin: auto;
        width: 50%;
    }
    .buttons {
        display: flex;
    }
    .shop-nav {
        display: flex;
        justify-content: space-evenly;
        width: 25%;
        font-family: 'Times New Roman', Times, serif;
    }
    .shop-nav i {
        font-size: 30px;
        color: #96875A;
    }
    .shop-nav i:hover {
        color: #3A3A3A;
    }
    .shopnav-label {
        text-decoration: none;
        color: black;
    }
    .shopnav-label:hover {
        color: #3A3A3A;
    }
    .price-data {
        background: #b1a57e;
        width: 35%;
        padding: 8px;
        margin-left: 33%;
    }
    .info1 {
        margin-left: 40px;
    }
    .info2 {
        margin-left: 50px;
    }
    .info3 {
        margin-left: 47px;
    }
    
    </style>
</head>
<body>
<!-- Navbar -->
<div class="navbar">
        <a href="nitifit.php" class="home text-dark"><h1>NitiFit</h1></a>
        <div class="navlist">
            <ul>
                <a href="nitifit.php" class="list"><li>Home</li></a>
                <a href="about.php" class="list"><li>About Us</li></a>
                <a href="nittech.php" class="list"><li>Nitinol Technology</li></a>
                <a href="how.php" class="list"><li>How it Works</li></a>
                <a href="shop.php" class="shop"><li>SHOP</li></a>
            </ul>
        </div>
        <form action="">
        <div class="searchBar">
            <input type="text" placeholder="Search">
            <button type="submit" class="search" ><i class="fa fa-search"></i></button>
        </div>
        </form>
    </div>
    <div class="menuBar">
        <div class="pointer">
            <div class="menu"></div>
            <div class="menu"></div>
            <div class="menu"></div>
        </div>
    </div>
    <div class="menuItems">
        <ul>
            <a href="stories.php" class="menuList"><li class="menubg">User Stories</li></a><br>
            <a href="forum.php" class="menuList"><li class="menubg">Community Forum</li></a><br>
            <a href="resources.php" class="menuList"><li class="menubg">Resources</li></a><br>
            <a href="faq.php" class="menuList"><li class="menubg">FAQs</li></a><br>
            <a href="contact.php" class="menuList"><li class="menubg">Contact Us</li></a><br>
            <a href="login.php" class="menuList"><li class="menubg">Log out</li></a>
        </ul>
    </div>


<!-- Content -->
<div class="container">
        <h3>My cart</h3>
        <hr>
        <div class="shop-nav">
            <div class="shop-button">
                <a href="shop.php" class="shopnav-label"><i class="fa fa-shopping-bag" id="bag"></i><p>Shop</p></a>
            </div>
            <div class="cart-button">
                <a href="cart.php" class="shopnav-label"><i class="fa fa-shopping-cart" id="cart"></i><p>Cart</p></a>
            </div>
            <div class="message-button">
                <a href="message.php" class="shopnav-label"><i class="fa fa-comment" id="message"></i><p>Message</p></a>
            </div>
        </div><br>
        <?php
                    
            $query = "SELECT * FROM `shop`";

            $result = mysqli_query($conn, $query);

            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
        ?>
        <div class="flex"> 
        <div class="card">
            <h4><?= $row ['itemname'] ?></h4>
            <p class="id"><?= $row ['itemid'] ?></p>
            <h5 class="price-data">₱<?= $row ['price'] ?>.00</h5>
            <hr id="hr">
            <p><strong>Color:</strong><target class="info1"><?= $row ['color'] ?></target></p>
            <p><strong>Size:</strong><target class="info2"><?= $row ['size'] ?></target></p>
            <p><strong>Quantity:</strong><target class="info3"><?= $row ['quantity'] ?></target></p>
            <hr>
            <div class="buttons">
                <a href="checkout.php" name="checkout" class="btn btn-success text-light w-50 mx-auto p-1" id="checkout"><i class='fa fa-shopping-bag'></i>Check Out</a>
                <a href="delete.php?id=<?= $row['id'] ?>" class="btn btn-danger text-light w-50 mx-auto p-1" ><i class='fa fa-trash'></i>Delete</a>
            </div>
        </div>
        </div>
        <?php
            }} else{
        ?>
        <p class="text">No Items added to Cart.</p>
        <?php } mysqli_close($conn);?>
</div>

<!-- Footer -->
<div class="footer">
        <div class="foot1">
            <h4>STAY CONNECTED</h4>
            <div class="icons">
            <p class="socmed"><i class="fa fa-twitter"></i></p>
            <p class="socmed"><i class="fa fa-instagram"></i></p>
            <p class="socmed"><i class="fa fa-facebook"></i></p>
            <p class="socmed"><i class="fa fa-pinterest"></i></p>
            </div>
        </div>
        <div class="foot2">
            <p>NitiFit</p>
            <p>@ 2024 by NitiFit • All Rights Reserved</p>
        </div>
        <div class="foot3">
            <h5>Contact Us</h5>
            <p class="cont">0912-345-6789</p>
            <p class="cont">info@nitifit.com</p>
        </div>
    </div>
</body>
<script>
    $(document).ready(function(){
        $(".pointer").click(function(){
            $(".menuItems").slideToggle();
        });
    });
</script>
</html>
