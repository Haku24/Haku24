<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="my_jquery_functions.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <title>Home</title>
    <style>
        body {
            padding: 0;
            margin: 0;
            background: #FFFCF4;
        }
    /*Navbar*/
    .navbar{
            border: 1px solid beige;
            padding-right: 4%;
            padding-left: 4%;
            padding-top: 2%;
            background: beige;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 4;
        }

        .home {
            text-decoration: none;
        }

        .navlist ul {
            display: flex;
            list-style-type: none;
            margin-top: 10px;
            padding: 0;
            margin-right: 335px;
        }
        .navlist li {
            margin-right: 20px;
            margin-left: 20px;
        }

        .list {
            text-decoration: none;
            color: black; /* Original color */
            font-size: 20px;
        }

        .list:hover {
            text-decoration: none;
            background-color: #96875A;
            border-radius: 30px;
            color: white;
        }

        .shop {
            text-decoration: none;
            border: 2px solid #3A3A3A;
            border-radius: 30px;
            color: #96875A;
            font-size: 20px;
            background-color: beige;
        }

        .shop:hover {
            text-decoration: none;
            border-radius: 30px;
            color: white;
            font-size: 20px;
            background-color: #96875A;
        }

        .searchBar {
            display: flex;
            align-items: center;
        }

        .searchBar input[type="text"] {
            border-radius: 20px;
            padding: 5px 10px;
            border: 1px solid #ccc;
        }

        .search{
            background: white;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .search:hover {
            background: #765700;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .menu {
            width: 30px;
            height: 4px;
            background-color: #3A3A3A;
            margin: 5.5px;
            border-radius: 15%;
        }
        .menuBar {
            border: 1px solid beige;
            background-color: beige;
            padding-bottom: 7px;
            width: 100%;
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            position: absolute;
            z-index: 3;
        }
        .pointer {
            cursor: pointer;
            width: 30px;
            margin-left: 59px;
        }
        /*Menu Bar*/
        .menuItems{
            background-color: rgba(245, 245, 220, 0.75);
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            width: 15%;
            padding-top: 60px;
            z-index: 2;
            position: absolute;
            display: none;
        }

        .menuList{
            text-decoration: none;
        }
        
        .menubg {
            list-style-type: none;
            width: 80%;
            padding: 5%;
            margin-top: 10px;
            border-radius: 50px;
            text-decoration: none;
            color: black; /* Original color */
        }
        .menubg:hover {
            text-decoration: none;
            list-style-type: none;
            background-color: #96875A;
            color: white;
        }
        
    .container {
            margin-top: 8%;
            margin-bottom: 10%;
        }

        .card {
            background-color: #96875A;
            color: beige;
        }

        .first {
            margin-left: 13%;
            font-size: 18px;
        }
        .second {
            font-size: 18px;
            line-height: 50px;
        }

    /* Footer */
    .footer {
            margin-top: 30px;
            background-color: #956c00;
            display: flex;
            text-align: center;
            color: white;
            width: 100%;
            padding-top: 10px;
            bottom: 0;
            left: 0;
         }

        .icons {
            margin-top: 40px;
        }

        .socmed {
            display: inline-block;
            margin-right: 10px; /* Adjust margin as needed */
        }

        .foot1 {
            margin-left: 7%;
        }

        .foot2 {
            margin-left: 20%;
            margin-top: 20px;
        }

        .foot3 {
            margin-left: 25%;
        }
    </style>
</head>
<body>
<!-- Navbar -->
<div class="navbar">
        <a href="nitifit.php" class="home text-dark"><h1>NitiFit</h1></a>
        <div class="navlist">
            <ul>
                <a href="nitifit.php" class="list"><li>Home</li></a>
                <a href="about.php" class="list"><li>About Us</li></a>
                <a href="nittech.php" class="list"><li>Nitinol Technology</li></a>
                <a href="how.php" class="list"><li>How it Works</li></a>
                <a href="shop.php" class="shop"><li>SHOP</li></a>
            </ul>
        </div>
        <form action="">
        <div class="searchBar">
            <input type="text" placeholder="Search">
            <button type="submit" class="search" ><i class="fa fa-search"></i></button>
        </div>
        </form>
    </div>
    <div class="menuBar">
        <div class="pointer">
            <div class="menu"></div>
            <div class="menu"></div>
            <div class="menu"></div>
        </div>
    </div>
    <div class="menuItems">
        <ul>
            <a href="stories.php" class="menuList"><li class="menubg">User Stories</li></a><br>
            <a href="forum.php" class="menuList"><li class="menubg">Community Forum</li></a><br>
            <a href="resources.php" class="menuList"><li class="menubg">Resources</li></a><br>
            <a href="faq.php" class="menuList"><li class="menubg">FAQs</li></a><br>
            <a href="contact.php" class="menuList"><li class="menubg">Contact Us</li></a><br>
            <a href="login.php" class="menuList"><li class="menubg">Log out</li></a>
        </ul>
    </div>

<!-- Content -->
<div class="container">
        <div class="card text-center w-50 p-2">
            <h4>Dive Deeper into Nitinol Research</h4>
        </div>
        <hr>
        <div class="content w-75 mx-5">
            <p class="first">
                This is a sample sentence. This is a sample sentence. This is a sample sentence. 
                This is a sample sentence.
            </p>
            <p class="second">
                This is a sample sentence. This is a sample sentence. This is a sample sentence. 
                This is a sample sentence. This is a sample sentence. This is a sample sentence.
            </p>
        </div><br><br>
        <div class="card text-center w-50 p-2">
            <h4>Links to Academic Papers, Books, and More </h4>
        </div>
        <hr>
        <div class="content w-75 mx-5">
            <p class="first">
                This is a sample sentence. This is a sample sentence. This is a sample sentence. 
                This is a sample sentence.
            </p>
            <p class="second">
                This is a sample sentence. This is a sample sentence. This is a sample sentence. 
                This is a sample sentence. This is a sample sentence. This is a sample sentence.
            </p>
        </div>
    </div>
<!-- Footer -->
<div class="footer">
        <div class="foot1">
            <h4>STAY CONNECTED</h4>
            <div class="icons">
            <p class="socmed"><i class="fa fa-twitter"></i></p>
            <p class="socmed"><i class="fa fa-instagram"></i></p>
            <p class="socmed"><i class="fa fa-facebook"></i></p>
            <p class="socmed"><i class="fa fa-pinterest"></i></p>
            </div>
        </div>
        <div class="foot2">
            <p>NitiFit</p>
            <p>@ 2024 by NitiFit • All Rights Reserved</p>
        </div>
        <div class="foot3">
            <h5>Contact Us</h5>
            <p class="cont">0912-345-6789</p>
            <p class="cont">info@nitifit.com</p>
        </div>
    </div>
</body>
<script>
    $(document).ready(function(){
        $(".pointer").click(function(){
            $(".menuItems").slideToggle();
        });
    });
</script>
</html>
