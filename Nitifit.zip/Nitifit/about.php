<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="my_jquery_functions.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <title>Home</title>
    <style>
        body {
            padding: 0;
            margin: 0;
            background: #FFFCF4;
        }
        /*Navbar*/
.navbar{
            border: 1px solid beige;
            padding-right: 4%;
            padding-left: 4%;
            padding-top: 2%;
            background: beige;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 4;
        }

        .home {
            text-decoration: none;
        }

        .navlist ul {
            display: flex;
            list-style-type: none;
            margin-top: 10px;
            padding: 0;
            margin-right: 335px;
        }
        .navlist li {
            margin-right: 20px;
            margin-left: 20px;
        }

        .listA {
            font-size: 20px;
            text-decoration: none;
            background-color: #96875A;
            border-radius: 30px;
            color: white;
        }

        .listA:hover {
            font-size: 20px;
            text-decoration: none;
            background-color: #96875A;
            border-radius: 30px;
            color: white;
        }

        .list {
            text-decoration: none;
            color: black; /* Original color */
            font-size: 20px;
        }

        .list:hover {
            text-decoration: none;
            background-color: #96875A;
            border-radius: 30px;
            color: white;
        }

        .shop {
            text-decoration: none;
            border: 2px solid #3A3A3A;
            border-radius: 30px;
            color: #96875A;
            font-size: 20px;
            background-color: beige;
        }

        .shop:hover {
            text-decoration: none;
            border-radius: 30px;
            color: white;
            font-size: 20px;
            background-color: #96875A;
        }

        .searchBar {
            display: flex;
            align-items: center;
        }

        .searchBar input[type="text"] {
            border-radius: 20px;
            padding: 5px 10px;
            border: 1px solid #ccc;
        }

        .search{
            background: white;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .search:hover {
            background: #765700;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .menu {
            width: 30px;
            height: 4px;
            background-color: #3A3A3A;
            margin: 5.5px;
            border-radius: 15%;
        }
        .menuBar {
            border: 1px solid beige;
            background-color: beige;
            padding-bottom: 7px;
            width: 100%;
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            position: absolute;
            z-index: 3;
        }
        .pointer {
            cursor: pointer;
            width: 30px;
            margin-left: 59px;
        }
        /*Menu Bar*/
        .menuItems{
            background-color: rgba(245, 245, 220, 0.75);
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            width: 15%;
            padding-top: 60px;
            z-index: 2;
            position: absolute;
            display: none;
        }

        .menuList{
            text-decoration: none;
        }
        
        .menubg {
            list-style-type: none;
            width: 80%;
            padding: 5%;
            margin-top: 10px;
            border-radius: 50px;
            text-decoration: none;
            color: black; /* Original color */
        }
        .menubg:hover {
            text-decoration: none;
            list-style-type: none;
            background-color: #96875A;
            color: white;
        }
        
        /* Content */
        
.container {
            margin-top: 80px;
            text-align: center;
        }
        .title {
            color: #96875A;
            font-style: italic;
        }
        .hr {
            border: 1px solid #956c00;
            width: 25px;
            margin-top: 25px;
            margin-left: 49%;
        }
        .res {
            color: #956c00;
            font-size: 19px;
        }
        .layers {
            display: flex;
            justify-content: center;
            justify-content: space-between;
            margin-left: 7%;
            margin-bottom: 30px;
        }
        img {
            width: 90%;
            margin-top: 50px;
        }
        .desc {
            background: #b0a47b;
            width: 90%;
            padding-top: 50px;
            padding-bottom: 50px;
        }
        .name {
            font-family: 'Times New Roman', Times, serif;
            margin-left: 30px;
        }

        .bio {
            font-size: 17px;
            margin-left: 30px;
        }
        .social {
            color: black;
            font-size: 25px;
            margin-left: 5px
        }
        .icon-social {
            margin-left: 25px;
            margin-top: 70px;
        }

.journey {
    display: flex;
    background-color: #5b4200;
    color: beige;
    }
    .journey-title h1 {
        font-size: 65px;
        text-align: center;
        margin-left: 23%;
        padding-top: 90px;
        padding-left: 50px;
    }
    .journey-content {
        width: 55%;
        margin-left: 10%;
        padding-top: 60px;
        padding-bottom: 40px;
        font-size: 17px;
        line-height: 30px;
    }
    .readMore {
        text-decoration: none;
        color: beige;
    }
    .readMore:hover {
        text-decoration: none;
        color: #96875A;
    }

         /* Footer */
.footer {
            margin-top: 30px;
            background-color: #956c00;
            display: flex;
            text-align: center;
            color: white;
            width: 100%;
            padding-top: 10px;
            bottom: 0;
            left: 0;
         }

        .icons {
            margin-top: 40px;
        }

        .socmed {
            display: inline-block;
            margin-right: 10px; /* Adjust margin as needed */
        }

        .foot1 {
            margin-left: 7%;
        }

        .foot2 {
            margin-left: 20%;
            margin-top: 20px;
        }

        .foot3 {
            margin-left: 25%;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
<div class="navbar">
        <a href="nitifit.php" class="home text-dark"><h1>NitiFit</h1></a>
        <div class="navlist">
            <ul>
                <a href="nitifit.php" class="list"><li>Home</li></a>
                <a href="about.php" class="listA"><li>About Us</li></a>
                <a href="nittech.php" class="list"><li>Nitinol Technology</li></a>
                <a href="how.php" class="list"><li>How it Works</li></a>
                <a href="shop.php" class="shop"><li>SHOP</li></a>
            </ul>
        </div>
        <form action="">
        <div class="searchBar">
            <input type="text" placeholder="Search">
            <button type="submit" class="search" ><i class="fa fa-search"></i></button>
        </div>
        </form>
    </div>
    <div class="menuBar">
        <div class="pointer">
            <div class="menu"></div>
            <div class="menu"></div>
            <div class="menu"></div>
        </div>
    </div>
    <div class="menuItems">
        <ul>
            <a href="stories.php" class="menuList"><li class="menubg">User Stories</li></a><br>
            <a href="forum.php" class="menuList"><li class="menubg">Community Forum</li></a><br>
            <a href="resources.php" class="menuList"><li class="menubg">Resources</li></a><br>
            <a href="faq.php" class="menuList"><li class="menubg">FAQs</li></a><br>
            <a href="contact.php" class="menuList"><li class="menubg">Contact Us</li></a><br>
            <a href="login.php" class="menuList"><li class="menubg">Log out</li></a>
        </ul>
    </div>
        <!-- Content -->


<div class="container">
        <h1 class="title">Meet The Team</h1>
    </div>
    <div class="hr"></div><br>
    <center><p class="res">The Nitinol-Laced Product Researchers</p></center>
    <div class="layers">
    <div class="layer1">
        <div class="img">
            <img src="img/gonzales.webp" alt="image">
            <div class="desc">
                <h5 class="name">Liandrey Hanz S. Gonzales</h5>
                <br>
                <p class="bio">
                Add a short bio for each team member. 
                Make <br> it brief and informative to keep visitors <br> engaged.
                </p>
                <div class="icon-social">
                <a href="#" class="social"><i class="fa fa-facebook"></i></a>
                <a href="#" class="social"><i class="fa fa-twitter"></i></a>
                <a href="#" class="social"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>
        <div class="img">
            <img src="img/kiakan.webp" alt="image">
            <div class="desc">
            <h5 class="name">Sherjamyrrh T. Macalintangui</h5>
                <br>
                <p class="bio">
                Add a short bio for each team member. 
                Make <br> it brief and informative to keep visitors <br> engaged.
                </p>
                <div class="icon-social">
                <a href="#" class="social"><i class="fa fa-facebook"></i></a>
                <a href="#" class="social"><i class="fa fa-twitter"></i></a>
                <a href="#" class="social"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="layer2">
        <div class="img">
            <img src="img/kalipa.webp" alt="image">
            <div class="desc">
            <h5 class="name">Aryadhni C. Kalipa</h5>
                <br>
                <p class="bio">
                Add a short bio for each team member. 
                Make <br> it brief and informative to keep visitors <br> engaged.
                </p>
                <div class="icon-social">
                <a href="#" class="social"><i class="fa fa-facebook"></i></a>
                <a href="#" class="social"><i class="fa fa-twitter"></i></a>
                <a href="#" class="social"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>
        <div class="img">
            <img src="img/logo.webp" alt="image">
            <div class="desc">
            <h5 class="name">Notre Dame - RVM College of Cotabato</h5>
                <br>
                <p class="bio">
                Add a short bio for each team member. 
                Make <br> it brief and informative to keep visitors <br> engaged.
                </p>
                <div class="icon-social">
                <a href="#" class="social"><i class="fa fa-facebook"></i></a>
                <a href="#" class="social"><i class="fa fa-twitter"></i></a>
                <a href="#" class="social"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="layer3">
        <div class="img">
            <img src="img/kiakan.webp" alt="image">
            <div class="desc">
            <h5 class="name">Sittie Aisah S. Kiakan</h5>
                <br>
                <p class="bio">
                Add a short bio for each team member. 
                Make <br> it brief and informative to keep visitors <br> engaged.
                </p>
                <div class="icon-social">
                <a href="#" class="social"><i class="fa fa-facebook"></i></a>
                <a href="#" class="social"><i class="fa fa-twitter"></i></a>
                <a href="#" class="social"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>
        <div class="img">
            <img src="img/kalipa.webp" alt="image">
            <div class="desc">
            <h5 class="name">Numan S. Sulaiman</h5>
                <br>
                <p class="bio">
                Add a short bio for each team member. 
                Make <br> it brief and informative to keep visitors <br> engaged.
                </p>
                <div class="icon-social">
                <a href="#" class="social"><i class="fa fa-facebook"></i></a>
                <a href="#" class="social"><i class="fa fa-twitter"></i></a>
                <a href="#" class="social"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    </div>

<div class="journey">
        <div class="journey-title">
            <h1>Our Journey</h1>
        </div>
        <div class="journey-content">
            <p>
            At Notre-Dame RVM College of Cotabato, 
            a team of students led by Liandrey, Aryadhni, 
            Sittie Aisah, Sherjamyrrh, and Numan embarked 
            on a journey to create Tight-in-All: Nitinol-laced 
            clothing capable of adjusting to fit a range of 
            sizes. Under Mrs. Ann P. Prias guidance, they 
            researched, designed, and tested their invention, 
            overcoming challenges with determination. 
            Their creation, Tight-in-All, revolutionized 
            garment design, symbolizing progress in apparel 
            innovation. Their journey showcased the power of 
            teamwork, perseverance, and innovation in pushing 
            boundaries and shaping the future of fashion.
            </p><hr>
            <a href="#" class="readMore">Read more</a>
        </div>
    </div>


    <!-- Footer -->
<div class="footer">
        <div class="foot1">
            <h4>STAY CONNECTED</h4>
            <div class="icons">
            <p class="socmed"><i class="fa fa-twitter"></i></p>
            <p class="socmed"><i class="fa fa-instagram"></i></p>
            <p class="socmed"><i class="fa fa-facebook"></i></p>
            <p class="socmed"><i class="fa fa-pinterest"></i></p>
            </div>
        </div>
        <div class="foot2">
            <p>NitiFit</p>
            <p>@ 2024 by NitiFit • All Rights Reserved</p>
        </div>
        <div class="foot3">
            <h5>Contact Us</h5>
            <p class="cont">0912-345-6789</p>
            <p class="cont">info@nitifit.com</p>
        </div>
    </div>
</body>
<script>
    $(document).ready(function(){
        $(".pointer").click(function(){
            $(".menuItems").slideToggle();
        });
    });
</script>
</html>
