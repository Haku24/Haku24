<?php 

include_once 'config.php';

if(isset($_POST['addtocart'])){

    $itemname = $_POST['itemname'];
    $itemid = $_POST['itemid'];
    $size = $_POST['size'];
    $color = $_POST['color'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];

    $query = "INSERT INTO `shop` (`itemid`,`itemname`,`size`, `color`, `quantity`, `price`) VALUES ('$itemid','$itemname','$size', '$color', '$quantity', '$price')";

    if(mysqli_query($conn, $query)){
        echo "<script>
                alert('Item added to cart successfully!');
                location.href='cart.php';
              </script>";
    }else{
        echo "<script>
                alert('Item was not added to cart!');
              </script>";
    }

    mysqli_close($conn);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="my_jquery_functions.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <title>Home</title>
    <style>
        body {
            padding: 0;
            margin: 0;
            background: #FFFCF4;
        }
/*Navbar*/
.navbar{
            border: 1px solid beige;
            padding-right: 4%;
            padding-left: 4%;
            padding-top: 2%;
            background: beige;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 4;
        }

        .home {
            text-decoration: none;
        }

        .navlist ul {
            display: flex;
            list-style-type: none;
            margin-top: 10px;
            padding: 0;
            margin-right: 335px;
        }
        .navlist li {
            margin-right: 20px;
            margin-left: 20px;
        }

        .list {
            text-decoration: none;
            color: black; /* Original color */
            font-size: 20px;
        }

        .list:hover {
            text-decoration: none;
            background-color: #96875A;
            border-radius: 30px;
            color: white;
        }

        .shop {
            text-decoration: none;
            border: 2px solid #3A3A3A;
            border-radius: 30px;
            color: #96875A;
            font-size: 20px;
            background-color: beige;
        }

        .shop:hover {
            text-decoration: none;
            border-radius: 30px;
            color: white;
            font-size: 20px;
            background-color: #96875A;
        }

        .searchBar {
            display: flex;
            align-items: center;
        }

        .searchBar input[type="text"] {
            border-radius: 20px;
            padding: 5px 10px;
            border: 1px solid #ccc;
        }

        .search{
            background: white;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .search:hover {
            background: #765700;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .menu {
            width: 30px;
            height: 4px;
            background-color: #3A3A3A;
            margin: 5.5px;
            border-radius: 15%;
        }
        .menuBar {
            border: 1px solid beige;
            background-color: beige;
            padding-bottom: 7px;
            width: 100%;
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            position: absolute;
            z-index: 3;
        }
        .pointer {
            cursor: pointer;
            width: 30px;
            margin-left: 59px;
        }
        /*Menu Bar*/
        .menuItems{
            background-color: rgba(245, 245, 220, 0.75);
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            width: 15%;
            padding-top: 60px;
            z-index: 2;
            position: absolute;
            display: none;
        }

        .menuList{
            text-decoration: none;
        }
        
        .menubg {
            list-style-type: none;
            width: 80%;
            padding: 5%;
            margin-top: 10px;
            border-radius: 50px;
            text-decoration: none;
            color: black; /* Original color */
        }
        .menubg:hover {
            text-decoration: none;
            list-style-type: none;
            background-color: #96875A;
            color: white;
        }
        
/* Content */
.container {
        /* border: 1px solid black; */
        margin-top: 5%;
        margin-right: auto;
        margin-left: auto;
        padding: 30px;
        margin-bottom: 100px;
    }
    .title {
        text-align: center;
        letter-spacing: 5px;
        background-color: #96875A;
        padding: 5px;
    }
    .products {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        margin-left: 5%;
    }
    .image {
        width: 230px;
        height: 250px;
    }
    .img {
        margin: 35px;
        cursor: pointer;
    }
    .label {
        width: 230px;
        height: 80px;
        background-color: #b0a47d;
        color: black;
        font-family: 'Times New Roman', Times, serif;
        padding: 13px;
    }
    .arr {
        display: flex;
    }
    .filter-side {
        width: 350px;
        margin-top: 30px;
    }
    .filter {
        font-size: 25px;
        font-family: 'Times New Roman', Times, serif;
    }
    .price-range {
        font-size: 18px;
        color: white;
        margin-bottom: 20px;
        font-family: 'Times New Roman', Times, serif;
        background-color: black;
        text-align: center;
    }
    .buttons button {
        font-size: 18px;
        margin: 0 10px;
        cursor: pointer;
    }
    .buttons {
        margin-left: 60px;
    }
    .adjust {
        font-size: 20px;
    }
    .hide {
        display: none;
    }
    #icon {
        margin-left: 140px;
        cursor: pointer;
    }
    #icon1 {
        margin-left: 140px;
        cursor: pointer;
    }
    .overlay {
        position: absolute;
        margin-top: 12.6%;
        background-color: rgba(0, 0, 0, 0.5);
        font-family: 'Times New Roman', Times, serif;
        color: #f1f1f1; 
        width: 230px;
        transition: .5s ease;
        opacity:0;
        color: white;
        font-size: 17px;
        padding: 17px;
        text-align: center;
    }

    .img:hover .overlay {
        opacity: 1;
    }
    .hide1 {
        display: none;
    }
    .radios {
        display: flex;
        justify-content: space-evenly;
    }
    .radio {
        border: 2px solid gray;
        border-radius: 50px;
        padding: 20px;
        width: 20px;
        cursor: pointer;
        background: gray;
    }
    .shop-nav {
        display: flex;
        justify-content: space-evenly;
        width: 25%;
        font-family: 'Times New Roman', Times, serif;
    }
    .shop-nav i {
        font-size: 30px;
        color: #96875A;
    }
    .shop-nav i:hover {
        color: #3A3A3A;
    }
    .shopnav-label {
        text-decoration: none;
        color: black;
    }
    .shopnav-label:hover {
        color: #3A3A3A;
    }

/* View */
.containers {
            max-width: 800px;
            margin-top: 100px;
            background-color: beige;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            font-family: 'Times New Roman', Times, serif;
            position: absolute;
            z-index: 9;
            margin-left: 24%;
            display: none;
        }
        .imgs {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        select {
            margin-bottom: 10px;
            width: 64%;
            padding: 2%;
            border-radius: 10px;
            border: 0.5px solid black;
        }
        .buttonton {
            background-color: #96875A;
            color: white;
            padding: 8px 18px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .buttonton:hover {
            background-color: #867951;
        }
        .set-color {
            border: 2px solid gray;
            border-radius: 20px;
            width: 20px;
            background-color: #4CAF50;
            padding: 10px;
        }
        .product-flex {
            display: flex;
        }
        .modify {
            margin-left: 30px;
            font-size: 18px;
            letter-spacing: 1px;
        }
        .presyo {
            width: 20%;
        }
        .id{
            font-size: 10px;
        }
        #cancel {
            margin-left: 160px;
            cursor: pointer;
        }
        #cancellong {
            margin-left: 100px;
            cursor: pointer;
        }
        #cancelyin {
            margin-left: 200px;
            cursor: pointer;
        }
        #cancelblack {
            margin-left: 150px;
            cursor: pointer;
        }
        #cancelsleeves {
            margin-left: 70px;
            cursor: pointer;
        }
        .more {
            cursor: pointer;
        }
        #more-pleated {
            display: none;
        }
        #more-longcoat {
            display: none;
        }
        #more-yin {
            display: none;
        }
        #more-black {
            display: none;
        }
        #more-sleeves {
            display: none;
        }


/* Footer */
.footer {
            margin-top: 30px;
            background-color: #956c00;
            display: flex;
            text-align: center;
            color: white;
            width: 100%;
            padding-top: 10px;
            bottom: 0;
            left: 0;
         }

        .icons {
            margin-top: 40px;
        }

        .socmed {
            display: inline-block;
            margin-right: 10px; /* Adjust margin as needed */
        }

        .foot1 {
            margin-left: 7%;
        }

        .foot2 {
            margin-left: 20%;
            margin-top: 20px;
        }

        .foot3 {
            margin-left: 25%;
        }
    </style>
</head>
<body>
<!-- Navbar -->
<div class="navbar">
        <a href="nitifit.php" class="home text-dark"><h1>NitiFit</h1></a>
        <div class="navlist">
            <ul>
                <a href="nitifit.php" class="list"><li>Home</li></a>
                <a href="about.php" class="list"><li>About Us</li></a>
                <a href="nittech.php" class="list"><li>Nitinol Technology</li></a>
                <a href="how.php" class="list"><li>How it Works</li></a>
                <a href="shop.php" class="shop"><li>SHOP</li></a>
            </ul>
        </div>
        <form action="">
        <div class="searchBar">
            <input type="text" placeholder="Search">
            <button type="submit" class="search" ><i class="fa fa-search"></i></button>
        </div>
        </form>
    </div>
    <div class="menuBar">
        <div class="pointer">
            <div class="menu"></div>
            <div class="menu"></div>
            <div class="menu"></div>
        </div>
    </div>
    <div class="menuItems">
        <ul>
            <a href="stories.php" class="menuList"><li class="menubg">User Stories</li></a><br>
            <a href="forum.php" class="menuList"><li class="menubg">Community Forum</li></a><br>
            <a href="resources.php" class="menuList"><li class="menubg">Resources</li></a><br>
            <a href="faq.php" class="menuList"><li class="menubg">FAQs</li></a><br>
            <a href="contact.php" class="menuList"><li class="menubg">Contact Us</li></a><br>
            <a href="login.php" class="menuList"><li class="menubg">Log out</li></a>
        </ul>
    </div>

<!-- View -->
<form action="" method="post" class="containers" id="pleated">
    <div class="product-flex">
    <div class="product-image">
        <img src="/img/pleated.webp" alt="Product Image" class="imgs">
    </div>
    <div class="modify">
    <div class="size">
        <h3>NitiFit Pleated Skirt<i class="material-icons" id="cancel">cancel</i></h3>
        <input type="text" name="itemname" value="NitiFit Pleated Skirt" style="display: none;" readonly>
        <p class="id">SKU: 0004</p>
        <input type="text" name="itemid" value="SKU: 0004" style="display: none;" readonly>
        <p>Available Sizes:</p>
        <select class="form-select" name="size">
            <option value="Small">Small</option>
            <option value="Medium">Medium</option>
            <option value="Large">Large</option>
            <option value="XL">XL</option>
            <option value="XXL">XXL</option>
        </select>
    </div> 
    <div class="kulay">
         <p>Color: Green</p>
            <div class="set-color"></div>
            <input type="text" name="color" value="Green" style="display: none;">
    </div>
    <div class="quantity">
        <p>Quantity:</p>
        <input type="number" name="quantity" min="1" value="1">
        <input type="submit" name="addtocart" class="buttonton" value="Add to cart">
    </div>
    </div>
    </div>
    <div class="buy">
        <div class="presyo btn btn-light text-dark">₱669.00</div>
        <input type="text" name="price" style="display: none;" value="669" readonly>
        <br><br>
        <h2>Description:</h2>
        <p>Introducing the Nitinol Pleated Skirt: meticulously 
            crafted with precision and sophistication, this 
            innovative garment integrates embedded Nitinol wires 
            to offer a tailored fit that dynamically adapts to 
            the wearer's body, ensuring both comfort and elegance. 
            Harnessing the remarkable shape memory properties 
            inherent to Nitinol, the skirt's pleats maintain their 
            pristine form, exuding a refined appearance suitable 
            for any occasion, from professional settings to formal 
            events. Engineered with a focus on durability and versatility, 
            the Nitinol Pleated Skirt seamlessly transitions between 
            various environments, embodying a harmonious blend of timeless 
            style and cutting-edge technology. Experience the pinnacle of 
            sophistication with the Nitinol Pleated Skirt, where 
            tradition meets innovation in contemporary fashion.</p>
            <p class="more" id="more1">More Info...</p>
            <div class="container border border-1 border-dark bg-light rounded p-5 mx-auto" id="more-pleated">
                <p class="product-info">Product Info</p><br>
                <p>The Nitinol Pleated Skirt offers:</p>
                <p>1. Tailored Fit: Engineered with embedded Nitinol wires, the skirt dynamically conforms to the wearer's body shape, ensuring a customized and comfortable fit.</p>
                <p>2. Enhanced Pleat Retention: Leveraging the shape memory properties of Nitinol, the pleats maintain their crispness and structure, preserving the skirt's polished appearance throughout wear.</p>
                <p>3. Versatile Style: Designed for versatility, the Nitinol Pleated Skirt effortlessly transitions from professional settings to formal occasions, making it a versatile wardrobe staple.</p>
                <p>4. Durability: Crafted with meticulous attention to detail and high-quality materials, the skirt is built to withstand daily wear, promising long-lasting performance.</p>
                <p>5. Innovative Design: Representing a fusion of traditional elegance and modern technology, the Nitinol Pleated Skirt exemplifies innovative apparel design, setting new standards in contemporary fashion.</p>
            </div>
        <h2>Product Reviews:</h2>
        <div class="review border border-1 border-dark w-100 p-4 bg-light">
            <h5>No reviews yet.</h5>
        </div>
    </form>
        </div>
<!-- long coat -->
<form action="" method="post" class="containers" id="longcoat">
    <div class="product-flex">
    <div class="product-image">
        <img src="/img/longcoat.webp" alt="Product Image" class="imgs">
    </div>
    <div class="modify">
    <div class="size">
        <h3>NitiFit Long Coat<i class="material-icons" id="cancellong">cancel</i></h3>
        <input type="text" name="itemname" value="NitiFit Long Coat" style="display: none;" readonly>
        <p class="id">SKU: 0012</p>
        <input type="text" name="itemid" value="SKU: 0012" style="display: none;" readonly>
        <p>Available Sizes:</p>
        <select class="form-select" name="size">
            <option value="Small">Small</option>
            <option value="Medium">Medium</option>
            <option value="Large">Large</option>
            <option value="XL">XL</option>
            <option value="XXL">XXL</option>
        </select>
    </div> 
    <div class="kulay">
         <p>Color: Black</p>
            <div class="set-color"></div>
            <input type="text" name="color" value="Black" style="display: none;">
    </div>
    <div class="quantity">
        <p>Quantity:</p>
        <input type="number" name="quantity" min="1" value="1">
        <input type="submit" name="addtocart" class="buttonton" value="Add to cart">
    </div>
    </div>
    </div>
    <div class="buy">
        <div class="presyo btn btn-light text-dark">₱1,669.00</div>
        <input type="text" name="price" value="1699" style="display: none;" readonly>
        <br><br>
        <h2>Description:</h2>
        <p>Introducing our Nitinol Long Coat – 
            a pinnacle of innovation and style. 
            Crafted with cutting-edge Nitinol alloy 
            technology, this coat offers a perfect blend 
            of form and function. Experience unparalleled 
            comfort with its adaptive fit, as it molds to 
            your body for a personalized feel. Designed for 
            durability, flexibility, and lightweight wear, 
            it's your ideal companion for any occasion. Stay 
            effortlessly chic and ready for anything with 
            our Nitinol Long Coat – where science meets 
            fashion at its finest.</p>
            <p class="more" id="more2">More Info...</p>
            <div class="container border border-1 border-dark bg-light rounded p-5 mx-auto" id="more-longcoat">
                <p class="product-info">Product Info</p><br>
                <p>The Nitinol Long Coat offers:</p>
                <p>1. Adaptive Fit: Tailors to your body for a personalized feel.</p>
                <p>2. Flexibility: Allows easy movement without losing shape.</p>
                <p>3. Lightweight: Ensures comfort for extended wear.</p>
                <p>4. Temperature Regulation: Maintains optimal body temperature.</p>
                <p>5. Durability: Resists wear and tear for long-lasting use.</p>
                <p>6. Versatility: Suitable for various occasions.</p>
                <p>7. Innovative Design: Fuses science and fashion seamlessly.</p>
                <p>8. Resilience: Maintains shape and elasticity over time.</p>
            </div>
        <h2>Product Reviews:</h2>
        <div class="review border border-1 border-dark w-100 p-4 bg-light">
            <h5>No reviews yet.</h5>
        </div>
    </form>
    </div>
<!-- yin yang -->
<form action="" method="post" class="containers" id="yinyang">
    <div class="product-flex">
    <div class="product-image">
        <img src="/img/yinyang.webp" alt="Product Image" class="imgs">
    </div>
    <div class="modify">
    <div class="size">
        <h3>NitiFit Yin Yang<i class="material-icons" id="cancelyin">cancel</i></h3>
        <input type="text" name="itemname" value="NitiFit Yin Yang" style="display: none;" readonly>
        <p class="id">SKU: 0008</p>
        <input type="text" name="itemid" value="SKU: 0008" style="display: none;" readonly>
        <p>Available Sizes:</p>
        <select class="form-select" name="size">
            <option value="Small">Small</option>
            <option value="Medium">Medium</option>
            <option value="Large">Large</option>
            <option value="XL">XL</option>
            <option value="XXL">XXL</option>
        </select>
    </div> 
    <div class="kulay">
         <p>Color: Black & White</p>
            <div class="set-color"></div>
            <input type="text" name="color" value="B & W" style="display: none;">
    </div>
    <div class="quantity">
        <p>Quantity:</p>
        <input type="number" name="quantity" min="1" value="1">
        <input type="submit" name="addtocart" class="buttonton" value="Add to cart">
    </div>
    </div>
    </div>
    <div class="buy">
        <div class="presyo btn btn-light text-dark">₱1,099.00</div>
        <input type="text" name="price" value="1099" style="display: none;" readonly>
        <br><br>
        <h2>Description:</h2>
        <p>Introducing the Nitinol Dress: meticulously 
            crafted with embedded Nitinol wires, this 
            avant-garde garment offers a tailored fit that 
            dynamically adjusts to the wearer's body, ensuring 
            both comfort and elegance. Leveraging the shape memory 
            properties inherent to Nitinol, the dress maintains its 
            refined silhouette and structure, exuding sophistication 
            and charm for any occasion. Engineered with versatility in 
            mind, the Nitinol Dress effortlessly transitions from daytime 
            chic to evening glamour, making it an indispensable addition to 
            any discerning wardrobe. Representing the pinnacle of sophistication 
            and innovation, the Nitinol Dress harmoniously merges 
            cutting-edge technology with timeless style, setting a 
            new standard in contemporary fashion.</p>
            <p class="more" id="more3">More Info...</p>
            <div class="container border border-1 border-dark bg-light rounded p-5 mx-auto" id="more-yin">
                <p class="product-info">Product Info</p><br>
                <p>The Nitinol Dress offers:</p>
                <p>1. Tailored Fit: With embedded Nitinol wires, the dress dynamically adapts to the wearer's body, ensuring a personalized and comfortable fit.</p>
                <p>2. Shape Retention: Leveraging Nitinol's shape memory properties, the dress maintains its refined silhouette and structure, maintaining an elegant appearance throughout wear.</p>
                <p>3. Versatile Style: Designed to seamlessly transition from daytime to evening, the Nitinol Dress is versatile enough to suit various occasions, from professional settings to formal events.</p>
                <p>4. Durability: Crafted with precision and high-quality materials, the dress promises durability and longevity, making it a reliable wardrobe staple.</p>
                <p>5. Innovative Design: Representing a fusion of cutting-edge technology and timeless elegance, the Nitinol Dress exemplifies innovative apparel design, offering a contemporary twist on classic style.</p>
            </div>
        <h2>Product Reviews:</h2>
        <div class="review border border-1 border-dark w-100 p-4 bg-light">
            <h5>No reviews yet.</h5>
        </div>
    </form>
    </div>
<!-- Black pants -->
<form action="" method="post" class="containers" id="blackpants">
    <div class="product-flex">
    <div class="product-image">
        <img src="/img/black.webp" alt="Product Image" class="imgs">
    </div>
    <div class="modify">
    <div class="size">
        <h3>NitiFit Black Pants<i class="material-icons" id="cancelblack">cancel</i></h3>
        <input type="text" name="itemname" value="NitiFit Black Pants" style="display: none;" readonly>
        <p class="id">SKU: 0003</p>
        <input type="text" name="itemid" value="SKU: 0003" style="display: none;" readonly>
        <p>Available Sizes:</p>
        <select class="form-select" name="size">
            <option value="Small">Small</option>
            <option value="Medium">Medium</option>
            <option value="Large">Large</option>
            <option value="XL">XL</option>
            <option value="XXL">XXL</option>
        </select>
    </div> 
    <div class="kulay">
         <p>Color: Off White</p>
            <div class="set-color"></div>
            <input type="text" name="color" value="Off White" style="display: none;">
    </div>
    <div class="quantity">
        <p>Quantity:</p>
        <input type="number" name="quantity" min="1" value="1">
        <input type="submit" name="addtocart" class="buttonton" value="Add to cart">
    </div>
    </div>
    </div>
    <div class="buy">
        <div class="presyo btn btn-light text-dark">₱799.00</div>
        <input type="text" name="price" value="799" style="display: none;" readonly>
        <br><br>
        <h2>Description:</h2>
        <p>Nitinol Black Pants are innovative garments 
            crafted with embedded Nitinol wires, renowned 
            for their shape memory properties. These pants 
            intelligently adapt to the wearer's body, ensuring 
            a personalized fit and maximum comfort throughout 
            the day. With sleek black styling and advanced 
            technology, Nitinol Black Pants represent a fusion of 
            style and functionality, ideal for modern individuals 
            seeking both fashion and practicality in their attire.</p>
            <p class="more" id="more4">More Info...</p>
            <div class="container border border-1 border-dark bg-light rounded p-5 mx-auto" id="more-black">
                <p class="product-info">Product Info</p><br>
                <p>The Nitinol Pants Offerings:</p>
                <p>1. Tailored Fit: Utilizing embedded Nitinol wires, these pants adapt meticulously to the wearer's physique, ensuring a bespoke and comfortable fit.</p>
                <p>2. Shape Integrity: Maintaining their original contours over prolonged wear, the pants exhibit the remarkable shape memory characteristics inherent to Nitinol, providing enduring elegance.</p>
                <p>3. Robustness: Crafted with premium-grade materials and employing advanced engineering, Nitinol Pants are engineered to endure daily usage, promising sustained performance.</p>
                <p>4. Versatility: Suited to a spectrum of occasions ranging from casual to formal, Nitinol Pants merge sophistication with practicality, embodying a versatile addition to any wardrobe.</p>
                <p>5. Innovativeness: Nitinol Pants epitomize pioneering apparel design, integrating state-of-the-art materials to deliver an unmatched wearing experience, thus defining a paradigm shift in sartorial innovation.</p>
            </div>
        <h2>Product Reviews:</h2>
        <div class="review border border-1 border-dark w-100 p-4 bg-light">
            <h5>No reviews yet.</h5>
        </div>
    </form>
    </div>
<!-- Long Sleeves -->
<form action="" method="post" class="containers" id="sleeves">
    <div class="product-flex">
    <div class="product-image">
        <img src="/img/longsleeves.webp" alt="Product Image" class="imgs">
    </div>
    <div class="modify">
    <div class="size">
        <h3>NitiFit Long Sleeves<i class="material-icons" id="cancelsleeves">cancel</i></h3>
        <input type="text" name="itemname" value="NitiFit Long Sleeves" style="display: none;" readonly>
        <p class="id">SKU: 0002</p>
        <input type="text" name="itemid" value="SKU: 0002" style="display: none;" readonly>
        <p>Available Sizes:</p>
        <select class="form-select" name="size">
            <option value="Small">Small</option>
            <option value="Medium">Medium</option>
            <option value="Large">Large</option>
            <option value="XL">XL</option>
            <option value="XXL">XXL</option>
        </select>
    </div> 
    <div class="kulay">
         <p>Color:  Black</p>
            <div class="set-color"></div>
            <input type="text" name="color" value=" Black" style="display: none;">
    </div>
    <div class="quantity">
        <p>Quantity:</p>
        <input type="number" name="quantity" min="1" value="1">
        <input type="submit" name="addtocart" class="buttonton" value="Add to cart">
    </div>
    </div>
    </div>
    <div class="buy">
        <div class="presyo btn btn-light text-dark">₱349.00Price</div>
        <input type="text" name="price" value="349" style="display: none;" readonly>
        <br><br>
        <h2>Description:</h2>
        <p>Introducing our Nitinol Long Sleeve: 
            precision-engineered with advanced Nitinol 
            alloy for a personalized fit, unmatched 
            comfort, and durability. Experience the 
            future of apparel with science-meets-style 
            innovation.</p>
            <p class="more" id="more5">More Info...</p>
            <div class="container border border-1 border-dark bg-light rounded p-5 mx-auto" id="more-sleeves">
                <p class="product-info">Product Info</p><br>
                <p>The Nitinol Long Sleeves Offerings:</p>
                <p>1. Adaptive Fit: Nitinol alloy technology allows the long sleeve to conform uniquely to each individual's body shape, providing a personalized and comfortable fit.</p>
                <p>2. Flexibility: The inherent elasticity of Nitinol ensures freedom of movement without compromising shape retention, offering flexibility for various activities and movements.</p>
                <p>3. Durability: Nitinol's robust properties make the long sleeve highly resistant to wear and tear, ensuring long-lasting performance and durability.</p>
                <p>4. Temperature Regulation: Nitinol has thermoregulatory properties, helping to maintain optimal body temperature by adapting to environmental changes, and keeping you comfortable in various conditions.</p>
                <p>5. Lightweight: Despite its durability, Nitinol is remarkably lightweight, offering a comfortable and unobtrusive wearing experience.</p>
                <p>6. Versatility: Suitable for a wide range of activities, from intense workouts to casual wear, the Nitinol long sleeve adapts seamlessly to different lifestyles and occasions.</p>
                <p>7. Innovative Design: The integration of Nitinol alloy represents a fusion of science and fashion, offering a unique and forward</p>
            </div>
        <h2>Product Reviews:</h2>
        <div class="review border border-1 border-dark w-100 p-4 bg-light">
            <h5>No reviews yet.</h5>
        </div>
    </form>
    </div>

<!-- more info -->

<!-- Content -->
<div class="container">
        <h3 class="title">SHOP</h3><br><hr>
        <div class="shop-nav">
            <div class="shop-button">
                <a href="shop.php" class="shopnav-label"><i class="fa fa-shopping-bag" id="bag"></i><p>Shop</p></a>
            </div>
            <div class="cart-button">
                <a href="cart.php" class="shopnav-label"><i class="fa fa-shopping-cart" id="cart"></i><p>Cart</p></a>
            </div>
            <div class="message-button">
                <a href="message.php" class="shopnav-label"><i class="fa fa-comment" id="message"></i><p>Message</p></a>
            </div>
    </div>
        <hr>
        <div class="arr">
            <div class="filter-side">
                <p class="filter">Filter by</p>
                <hr>
                <div class="price">
                    <p class="adjust">Price<i class="fa fa-angle-down" id="icon"></i></p>
                    <div class="hide">
                    <div class="price-range" id="priceRange">P500 - P1,500</div>
                    <div class="buttons">
                        <button onclick="decreasePrice()" class="btn btn-outline-dark" id="minus">-</button>
                        <button onclick="increasePrice()" class="btn btn-outline-dark" id="plus">+</button>
                    </div>
                    </div>
                </div>
                <hr>
                <div class="price">
                    <p class="adjust">Color<i class="fa fa-angle-down" id="icon1"></i></p>
                    <div class="hide1">
                    <div class="radios">
                    <div class="radio" id="radio1"></div>
                    <div class="radio" id="radio2"></div>
                    <div class="radio" id="radio3"></div>
                    </div>
                    </div>
                </div>
                <hr>
                <input type="button" id="all" class="btn btn-outline-dark" value="Show All">
            </div>
        <div class="products">
            <div class="img" id="below1">
            <div class="overlay" id="overlay1">Quick view</div>
                <img src="/img/pleated.webp" alt="Pleated Skirt" class="image">
                <div class="label">
                    <p>NitiFit Pleated Skirt <br>₱669.00</p>
                </div>
            </div>
            <div class="img" id="over1">
            <div class="overlay" id="overlay2">Quick view</div>
                <img src="/img/longcoat.webp" alt="Long Coat" class="image">
                <div class="label">
                    <p>NitiFit Long Coat<br>₱1,669.00</p>
                </div>
            </div>
            <div class="img" id="over2">
            <div class="overlay" id="overlay3">Quick view</div>
                <img src="/img/yinyang.webp" alt="Yin Yang" class="image">
                <div class="label">
                    <p>NitiFit Yin Yang Dress<br>₱1,099.00</p>
                </div>
            </div>
            <div class="img" id="below2">
            <div class="overlay" id="overlay4">Quick view</div>
                <img src="/img/black.webp" alt="Black Pants" class="image">
                <div class="label">
                    <p>NitiFit Black Pants<br>₱799.00</p>
                </div>
            </div>
            <div class="img" id="below3">
            <div class="overlay" id="overlay5">Quick view</div>
                <img src="/img/longsleeves.webp" alt=" long Sleeves" class="image">
                <div class="label">
                    <p>NitiFit Long Sleeves<br>₱349.00</p>
                </div>
            </div>
        </div>
        </div>
</div>



<!-- Footer -->
<div class="footer">
        <div class="foot1">
            <h4>STAY CONNECTED</h4>
            <div class="icons">
            <p class="socmed"><i class="fa fa-twitter"></i></p>
            <p class="socmed"><i class="fa fa-instagram"></i></p>
            <p class="socmed"><i class="fa fa-facebook"></i></p>
            <p class="socmed"><i class="fa fa-pinterest"></i></p>
            </div>
        </div>
        <div class="foot2">
            <p>NitiFit</p>
            <p>@ 2024 by NitiFit • All Rights Reserved</p>
        </div>
        <div class="foot3">
            <h5>Contact Us</h5>
            <p class="cont">0912-345-6789</p>
            <p class="cont">info@nitifit.com</p>
        </div>
    </div>
</body>
<script>
    $(document).ready(function(){
        $(".pointer").click(function(){
            $(".menuItems").slideToggle();
        });

        $("#icon").click(function(){
            $(".hide").slideToggle();
        });

        $("#icon1").click(function(){
            $(".hide1").slideToggle();
        });

        $("#radio1").click(function(){
            $(this).css("background", "black");
            $("#radio2").css("background", "gray");
            $("#radio3").css("background", "gray");
            $("#over1, #below2, below3").fadeIn();
            $("#over2, #below1").fadeOut();
        });
        $("#radio2").click(function(){
            $(this).css("background", "green");
            $("#radio1").css("background", "gray");
            $("#radio3").css("background", "gray");
            $("#below1").fadeIn();
            $("#over2, #below2, #over1, #below3").fadeOut();
        });
        $("#radio3").click(function(){
            $(this).css("background", "white");
            $("#radio1").css("background", "gray");
            $("#radio2").css("background", "gray");
            $("#over2").fadeIn();
            $("#below1, #below2, #over1, #below3").fadeOut();
        });

        $("#plus").click(function(){
            $("#over1").fadeIn();
            $("#over2").fadeIn();
            $("#below1").fadeOut();
            $("#below2").fadeOut();
            $("#below3").fadeOut();
        });

        $("#minus").click(function(){
            $("#below1").fadeIn();
            $("#below2").fadeIn();
            $("#below3").fadeIn();
            $("#over1").fadeOut();
            $("#over2").fadeOut();
        });

        $("#all").click(function(){
            $("#below1, #below2, #below3, #over1, #over2").show();
            $(".hide, .hide1").slideUp();
        });

        $("#overlay1").click(function(){
            $("#pleated").fadeIn();
        });
        $("#cancel").click(function(){
            $("#pleated").fadeOut();
        });
        $("#overlay2").click(function(){
            $("#longcoat").fadeIn();
        });
        $("#cancellong").click(function(){
            $("#longcoat").fadeOut();
        });

        $("#overlay3").click(function(){
            $("#yinyang").fadeIn();
        });
        $("#cancelyin").click(function(){
            $("#yinyang").fadeOut();
        });

        $("#overlay4").click(function(){
            $("#blackpants").fadeIn();
        });
        $("#cancelblack").click(function(){
            $("#blackpants").fadeOut();
        });

        $("#overlay5").click(function(){
            $("#sleeves").fadeIn();
        });
        $("#cancelsleeves").click(function(){
            $("#sleeves").fadeOut();
        });

        $("#more1").click(function(){
            $("#more-pleated").fadeToggle();
        });

        $("#more2").click(function(){
            $("#more-longcoat").fadeToggle();
        });
        $("#more3").click(function(){
            $("#more-yin").fadeToggle();
        });
        $("#more4").click(function(){
            $("#more-black").fadeToggle();
        });
        $("#more5").click(function(){
            $("#more-sleeves").fadeToggle();
        });
    });
</script>
<script src="shop.js"></script>
</html>
