let minPrice = 0;
let maxPrice = 1000;

function printPriceRange() {
  const priceRangeElement = document.getElementById('priceRange');
  priceRangeElement.textContent = `P${minPrice} - P${maxPrice}`;
}

function increasePrice() {
  if (maxPrice < 2000) {
    minPrice = maxPrice;
    maxPrice += 1000;
    if (maxPrice > 2000) {
      maxPrice = 2000;
    }
    printPriceRange();
  } else {
    alert("Price range cannot exceed P2,000.");
  }
}

function decreasePrice() {
  if (minPrice > 0) {
    maxPrice = minPrice;
    minPrice -= 1000;
    if (minPrice < 0) {
      minPrice = 0;
    }
    printPriceRange();
  } else {
    alert("Price range cannot go below P0.");
  }
}

// Initial print
printPriceRange();
