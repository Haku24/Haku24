<?php 

include_once 'config.php';

if(isset($_POST['send'])){

    $quest = $_POST['quest'];
    $name = $_POST['name'];
    $date = $_POST['date'];

    $query = "INSERT INTO `faq` (`question`,`username`,`date`) VALUES ('$quest','$name','$date')";

    if(mysqli_query($conn, $query)){
        echo "<script>
                alert('Question submitted successfully!');
                location.href='forum.php';
              </script>";
    }else{
        echo "<script>
                alert('Sending question failed!');
              </script>";
    }

    mysqli_close($conn);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="my_jquery_functions.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <title>Home</title>
    <style>
        body {
            padding: 0;
            margin: 0;
            background: #FFFCF4;
        }
/*Navbar*/
.navbar{
            border: 1px solid beige;
            padding-right: 4%;
            padding-left: 4%;
            padding-top: 2%;
            background: beige;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 4;
        }

        .home {
            text-decoration: none;
        }

        .navlist ul {
            display: flex;
            list-style-type: none;
            margin-top: 10px;
            padding: 0;
            margin-right: 335px;
        }
        .navlist li {
            margin-right: 20px;
            margin-left: 20px;
        }

        .list {
            text-decoration: none;
            color: black; /* Original color */
            font-size: 20px;
        }

        .list:hover {
            text-decoration: none;
            background-color: #96875A;
            border-radius: 30px;
            color: white;
        }

        .shop {
            text-decoration: none;
            border: 2px solid #3A3A3A;
            border-radius: 30px;
            color: #96875A;
            font-size: 20px;
            background-color: beige;
        }

        .shop:hover {
            text-decoration: none;
            border-radius: 30px;
            color: white;
            font-size: 20px;
            background-color: #96875A;
        }

        .searchBar {
            display: flex;
            align-items: center;
        }

        .searchBar input[type="text"] {
            border-radius: 20px;
            padding: 5px 10px;
            border: 1px solid #ccc;
        }

        .search{
            background: white;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .search:hover {
            background: #765700;
            border-radius: 50%;
            border: none;
            font-size: 20px;
            margin-left: 5px;
        }
        .menu {
            width: 30px;
            height: 4px;
            background-color: #3A3A3A;
            margin: 5.5px;
            border-radius: 15%;
        }
        .menuBar {
            border: 1px solid beige;
            background-color: beige;
            padding-bottom: 7px;
            width: 100%;
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            position: absolute;
            z-index: 3;
        }
        .pointer {
            cursor: pointer;
            width: 30px;
            margin-left: 59px;
        }
        /*Menu Bar*/
        .menuItems{
            background-color: rgba(245, 245, 220, 0.75);
            box-shadow: rgba(50, 50, 93, 0.20) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
            width: 15%;
            padding-top: 60px;
            z-index: 2;
            position: absolute;
            display: none;
        }

        .menuList{
            text-decoration: none;
        }
        
        .menubg {
            list-style-type: none;
            width: 80%;
            padding: 5%;
            margin-top: 10px;
            border-radius: 50px;
            text-decoration: none;
            color: black; /* Original color */
        }
        .menubg:hover {
            text-decoration: none;
            list-style-type: none;
            background-color: #96875A;
            color: white;
        }
        
/* Content */
.content {
        width: 75%;
        margin-left: 13%;
        background-color: beige;
        padding-left: 20px;
        padding-right: 20px;
    }
    .title {
        margin-top: 70px;
        text-align: center;
    }
    .qna {
        width: 65%;
        text-align: center;
        margin-top: 70px;
    }
    .faq {
        display: flex;
        justify-content: center;
        justify-content: space-around;
        margin-left: 15%;
    }
    .ask {
            margin-top: 560px;
            position: fixed;
            margin-left: 40px;
            display: flex;
            cursor: pointer;
            z-index: 2;
        }
        .comment {
            cursor: pointer;
            font-size: 70px;
        }
        .comment:hover {
            color: #645a3c;
        }
        .label {
            margin-top: 45px;
            margin-left: 10px;
        }
        .label:hover {
            color: #645a3c;
        }
        .question-form {
            position: fixed;
            width: 27%;
            color: white;
            padding: 30px;
            margin-left: 80px;
            margin-top: 120px;
            height: 480px;
            background-color: #645a3c;
            border-radius: 20px;
            display: none;
            z-index: 8;
        }
        .question-form p {
            font-size: 20px;
        }
        .name {
            padding: 2%;
            width: 75%;
            margin-bottom: 10px;
        }
        .quest {
            width: 100%;
            padding: 5%;
            padding-bottom: 100px;
            margin-bottom: 5px;
        }
        .send {
            padding: 2%;
            width: 40%;
            border: 1px solid #645a3c;
            background: black;
            color: white;
            border-radius: 5px;
        }
        .send:hover {
            padding: 2%;
            width: 40%;
            border: 1px solid #645a3c;
            background: white;
            color: black;
        }


/* Footer */
.footer {
            margin-top: 30px;
            background-color: #956c00;
            display: flex;
            text-align: center;
            color: white;
            width: 100%;
            padding-top: 10px;
            bottom: 0;
            left: 0;
            z-index: 3;
         }

        .icons {
            margin-top: 40px;
        }

        .socmed {
            display: inline-block;
            margin-right: 10px; /* Adjust margin as needed */
        }

        .foot1 {
            margin-left: 7%;
        }

        .foot2 {
            margin-left: 20%;
            margin-top: 20px;
        }

        .foot3 {
            margin-left: 25%;
        }
    </style>
</head>
<body>
<!-- Navbar -->
<div class="navbar">
        <a href="nitifit.php" class="home text-dark"><h1>NitiFit</h1></a>
        <div class="navlist">
            <ul>
                <a href="nitifit.php" class="list"><li>Home</li></a>
                <a href="about.php" class="list"><li>About Us</li></a>
                <a href="nittech.php" class="list"><li>Nitinol Technology</li></a>
                <a href="how.php" class="list"><li>How it Works</li></a>
                <a href="shop.php" class="shop"><li>SHOP</li></a>
            </ul>
        </div>
        <form action="">
        <div class="searchBar">
            <input type="text" placeholder="Search">
            <button type="submit" class="search" ><i class="fa fa-search"></i></button>
        </div>
        </form>
    </div>
    <div class="menuBar">
        <div class="pointer">
            <div class="menu"></div>
            <div class="menu"></div>
            <div class="menu"></div>
        </div>
    </div>
    <div class="menuItems">
        <ul>
            <a href="stories.php" class="menuList"><li class="menubg">User Stories</li></a><br>
            <a href="forum.php" class="menuList"><li class="menubg">Community Forum</li></a><br>
            <a href="resources.php" class="menuList"><li class="menubg">Resources</li></a><br>
            <a href="faq.php" class="menuList"><li class="menubg">FAQs</li></a><br>
            <a href="contact.php" class="menuList"><li class="menubg">Contact Us</li></a><br>
            <a href="login.php" class="menuList"><li class="menubg">Log out</li></a>
        </ul>
    </div>

<!-- Content -->
<div class="question-form">
        <p>Have any questions or concerns?</p><hr><br>
        <form action="faq.php" method="post">
            <input type="text" name="quest" class="quest" placeholder="What's your question?" required>
            <input type="text" name="name" class="name" placeholder="Enter your Name" required>
            <input type="text" name="date" class="name" placeholder="YYYY-MM-DD" required><br>
            <input type="submit" name="send" class="send" value="Send">
        </form>
        <br><hr>
    </div>
<div class="ask">
    <p class="comment"><i class="fa fa-comment"></i></p><h3 class="label">Ask question.</h3>
</div>
<div class="content">
    <h2 class="title">FAQ</h2><hr>
    <div class="faq">
    <div class="faq1">
        <div class="qna">
            <h4 class="question">Do you provide International delivery?</h4>
            <p class="answer">
            We offer international delivery for Nitinol products. 
            Shipping rates and delivery times may vary depending 
            on the destination country. Please note that additional 
            customs duties or taxes may apply, which are the 
            responsibility of the customer. For specific inquiries 
            regarding international delivery, please contact our 
            customer service team.
            </p>
        </div>
        <div class="qna">
            <h4 class="question">How do I return an item?</h4>
            <p class="answer">
            To return an item, please ensure it meets our return policy criteria: 
            unused, unwashed, and in its original condition with all tags attached. 
            Contact our customer service team within 30 days of purchase to initiate 
            the return process. We will provide you with further instructions and 
            may request additional information if necessary. Return shipping costs 
            are typically the responsibility of the customer unless the return is 
            due to a manufacturing defect or error on our part.
            </p>
        </div>
        <div class="qna">
            <h4 class="question">What is your returns policy?</h4>
            <p class="answer">
            Our returns policy allows for returns within 30 days of 
            purchase for eligible items. Returned items must be in 
            unused, unwashed, and undamaged condition with all original 
            tags attached. Once we receive and inspect the returned item, 
            we will notify you of the approval or rejection of your refund. 
            Refunds will be issued to the original method of payment. 
            Please note that shipping costs are non-refundable, unless 
            the return is due to a manufacturing defect or error on our part. 
            Exchanges for different sizes or colors are also available within 
            the same 30-day timeframe. If you have any further questions 
            regarding our returns policy, please feel free to contact our 
            customer service team for assistance.
            </p>
        </div>
    </div>
    <div class="faq2">
        <div class="qna">
            <h4 class="question">How do I track my order?</h4>
            <p class="answer">
            Once your Nitinol order has been shipped, 
            you will receive a shipping confirmation email 
            containing a tracking number and instructions on 
            how to track your order. You can use this 
            tracking number on our website or the courier's 
            website to monitor the status and location of your shipment.
            </p>
        </div>
        <div class="qna">
            <h4 class="question">How can I contact your couriers?</h4>
            <p class="answer">
            For inquiries regarding the delivery of your Nitinol order, 
            you can contact the courier directly using the contact 
            information provided in the shipping confirmation email. 
            Couriers typically offer customer service channels such as 
            phone, email, or online chat to assist with tracking, 
            delivery updates, and any other shipment-related queries.
            </p>
        </div>
        <div class="qna">
            <h4 class="question">What are your delivery options?</h4>
            <p class="answer">
            We offer various delivery options for Nitinol orders, 
            depending on your location and preferences. These options 
            may include standard shipping, express shipping, and 
            international shipping. Delivery times and costs may vary 
            based on the selected option and destination. During the 
            checkout process, you will be presented with available 
            delivery options, along with estimated delivery times and 
            associated costs, allowing you to choose the option that 
            best suits your needs. If you have specific delivery 
            requirements or questions about our delivery options, 
            please feel free to contact our customer service team for assistance.
            </p>
        </div>
    </div>
    </div>
</div>


<!-- Footer -->
<div class="footer">
        <div class="foot1">
            <h4>STAY CONNECTED</h4>
            <div class="icons">
            <p class="socmed"><i class="fa fa-twitter"></i></p>
            <p class="socmed"><i class="fa fa-instagram"></i></p>
            <p class="socmed"><i class="fa fa-facebook"></i></p>
            <p class="socmed"><i class="fa fa-pinterest"></i></p>
            </div>
        </div>
        <div class="foot2">
            <p>NitiFit</p>
            <p>@ 2024 by NitiFit • All Rights Reserved</p>
        </div>
        <div class="foot3">
            <h5>Contact Us</h5>
            <p class="cont">0912-345-6789</p>
            <p class="cont">info@nitifit.com</p>
        </div>
    </div>
</body>
<script>
    $(document).ready(function(){
        $(".pointer").click(function(){
            $(".menuItems").slideToggle();
        });
        
        $(".ask").click(function(){
            $(".question-form").fadeToggle();
        });
    });
</script>
</html>
